getwd()
install.packages("readr")
library(readr)
Biomart <- read_csv("Biomart.csv")
View(Biomart)
Biomart = Biomart[,c(3,4)]

id <- read_csv("id.txt", col_names = FALSE)
View(id)
names(id)[names(id) == "X1"] <- "Genes"

Biomart_genes_required = merge(id, Biomart, By = "Genes", all.x = T)
Biomart_genes_required = Biomart_genes_required[!duplicated(Biomart_genes_required$Genes),]
rownames(Biomart_genes_required) = Biomart_genes_required[,1]
Biomart_genes_required[,1] = NULL

refseq_ids <- read_csv("refseq_ids.txt", 
                       col_names = FALSE)
View(refseq_ids)
names(refseq_ids)[names(refseq_ids) == "X1"] <- "Transcript stable ID"
Biomart_transcript_required = merge(refseq_ids, Biomart, By = "Transcript stable ID", all.x = T)
rownames(Biomart_transcript_required) = Biomart_transcript_required[,1]
Biomart_transcript_required[,1] = NULL

Required_Biomart = rbind(Biomart_transcript_required, Biomart_genes_required)
Required_Biomart = cbind(rownames(Required_Biomart), Required_Biomart)
rownames(Required_Biomart) = NULL
names(Required_Biomart)[names(Required_Biomart) == "rownames(Required_Biomart)"] <- "IDs"

write.table(Required_Biomart, file = "Required_Biomart.txt", row.names = F, quote = F,col.names = T, sep = "\t")
write.table(Biomart_genes_required, file = "Required_genes_Biomart.txt", row.names = T, quote = F,col.names = T, sep = "\t")
write.table(Biomart_transcript_required, file = "Required_transcript_Biomart.txt", row.names = T, quote = F,col.names = T, sep = "\t")

mean <- read_csv("mean.txt", col_names = FALSE)
w <- read_csv("w.txt", col_names = FALSE)
expression_mean = cbind(w,mean)
names(expression_mean)[1] = "IDs"
names(expression_mean)[2] = "means"
final_file = merge(Required_Biomart, expression_mean, By = "IDs", all = T)
write.csv(final_file, file = "final_file.csv", row.names = F, col.names = T)
