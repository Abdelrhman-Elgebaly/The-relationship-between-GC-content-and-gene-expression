# Download the data set file
wget https://fantom.gsc.riken.jp/5/datafiles/latest/extra/gene_level_expression/hg19.gene_phase1and2combined_tpm.osc.txt.gz
# uncompress the file
gunzip hg19.gene_phase1and2combined_tpm.osc.txt.gz
# remove all transcripts
sed '/^ENST/d' hg19.gene_phase1and2combined_tpm.osc.txt > data.txt
# remove unknown lines
sed '/^#/d' data.txt > data1.txt
sed '/^00/d' data1.txt > data2.txt
# calculate the mean 
awk '{tot=0; for(i=1;i<=NF;i++) tot+=$i; print tot/i}' data2.txt > mean.txt
# extract the first column of the ID's 
cut -f1 data2.txt > id.txt
# count no. of lines 
wc -l mean.txt
wc -l id.txt
